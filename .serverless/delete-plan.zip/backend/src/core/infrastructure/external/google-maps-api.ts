// core/infrastructure/external/google-maps-api.ts
import { FetchDistanceParams, FetchDistanceResult } from '@trip-check/types'
import { URLSearchParams } from 'url'

// 環境変数からAPIキーを取得（Serverless環境などで注入される想定）
const API_KEY = process.env.GOOGLE_MAPS_API_KEY

if (!API_KEY) {
  throw new Error('Missing GOOGLE_MAPS_API_KEY in environment variables.')
}

/**
 * Google Maps Distance Matrix APIを用いて距離・所要時間を取得
 */
export async function fetchDistanceFromGoogleMaps(params: FetchDistanceParams): Promise<FetchDistanceResult> {
  const { fromLocation, toLocation, departureTime, transportType } = params

  new URLSearchParams({
    origins: fromLocation.name,
    destinations: toLocation.name,
    mode: transportType,
    departure_time: Math.floor(departureTime.getTime() / 1000).toString(),
    language: 'ja',
    key: API_KEY as string,
  })

  const searchParams = new URLSearchParams({
    origins: fromLocation.name,
    destinations: toLocation.name,
    mode: transportType,
    departure_time: Math.floor(departureTime.getTime() / 1000).toString(),
    language: 'ja',
    key: API_KEY as string,
  })

  const url = `https://maps.googleapis.com/maps/api/distancematrix/json?${searchParams.toString()}`

  const response = await fetch(url)

  if (!response.ok) {
    throw new Error(`Failed to fetch from Google Maps API: ${response.statusText}`)
  }

  const data = await response.json()

  const element = data?.rows?.[0]?.elements?.[0]

  if (!element || element.status !== 'OK') {
    throw new Error(`Invalid response from Google Maps API: ${JSON.stringify(element)}`)
  }

  return {
    durationMinutes: Math.ceil(element.duration.value / 60),
    distanceMeters: element.distance.value,
    summary: `${element.duration.text} / ${element.distance.text}`,
  }
}
