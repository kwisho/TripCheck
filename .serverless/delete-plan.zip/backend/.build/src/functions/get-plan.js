"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const utils_1 = require("@trip-check/utils");
const plan_service_js_1 = require("src/core/application/plan-service.js");
const handler = async (event) => {
    try {
        console.log('Query params:', event.queryStringParameters);
        console.log('Headers:', event.headers);
        console.log('Body:', event.body);
        const claims = event.requestContext?.authorizer?.jwt?.claims;
        const userId = claims?.sub;
        if (!userId) {
            return (0, utils_1.badRequest)('not found userId');
        }
        const startDate = new Date();
        const endDate = new Date();
        const planService = new plan_service_js_1.PlanService();
        const result = await planService.getPaged(userId, startDate, endDate, null, 10, '');
        return (0, utils_1.ok)(result.model);
    }
    catch (error) {
        console.error('Error occurred:', error);
        return (0, utils_1.badRequest)({ message: 'Unexpected error occurred.' });
    }
};
exports.handler = handler;
