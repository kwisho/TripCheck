"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const utils_1 = require("@trip-check/utils");
const map_route_service_1 = require("../core/application/map-route-service");
const handler = async (event) => {
    try {
        console.log('Query params:', event.queryStringParameters);
        console.log('Headers:', event.headers);
        console.log('Body:', event.body);
        const claims = event.requestContext?.authorizer?.jwt?.claims;
        const userId = claims?.sub;
        if (!userId) {
            return (0, utils_1.badRequest)('User ID not found.');
        }
        const query = event.queryStringParameters ?? {};
        if (!query.fromLocation || !query.toLocation || !query.departureTime || !query.transportType) {
            return (0, utils_1.badRequest)('Required query parameter is missing.');
        }
        let fromLocation, toLocation;
        try {
            fromLocation = JSON.parse(query.fromLocation);
            toLocation = JSON.parse(query.toLocation);
        }
        catch {
            return (0, utils_1.badRequest)('Invalid format for fromLocation or toLocation.');
        }
        const departureTime = new Date(query.departureTime);
        if (isNaN(departureTime.getTime())) {
            return (0, utils_1.badRequest)('Invalid format for departureTime.');
        }
        const transportType = query.transportType;
        const mapRouteService = new map_route_service_1.MapRouteService();
        const result = await mapRouteService.calculateRoute({
            fromLocation,
            toLocation,
            departureTime,
            transportType,
        });
        if (!result.model) {
            return (0, utils_1.badRequest)('Failed to retrieve route.');
        }
        return (0, utils_1.ok)(result.model);
    }
    catch (error) {
        console.error('Error occurred:', error);
        return (0, utils_1.badRequest)({ message: 'Unexpected error occurred.' });
    }
};
exports.handler = handler;
