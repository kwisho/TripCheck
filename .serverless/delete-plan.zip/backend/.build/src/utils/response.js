"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.unprocessableEntity = exports.notFound = exports.badRequest = exports.noContent = exports.created = exports.ok = exports.statusCode = void 0;
const badRequestProblemDetails = {
    type: 'https://tools.ietf.org/html/rfc7231#section-6.5.1',
    title: 'Invalid request.',
    status: 400,
};
const unprocessableEntityProblemDetails = {
    type: 'https://tools.ietf.org/html/rfc7231#section-6.5',
    title: 'Unprocessable entity.',
    status: 422,
};
const notFoundProblemDetails = {
    type: 'https://tools.ietf.org/html/rfc7231#section-6.5.4',
    title: 'The specified resource was not found.',
    status: 404,
};
const contentType = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
};
const contentTypeProblemDetails = {
    'Content-Type': 'application/problem+json',
    'Access-Control-Allow-Origin': '*',
};
const statusCode = (statusCode, data, headers) => {
    const body = data ? JSON.stringify(data) : '';
    return {
        statusCode,
        body,
        headers,
    };
};
exports.statusCode = statusCode;
const ok = (data) => (0, exports.statusCode)(200, data, contentType);
exports.ok = ok;
const created = (data, location) => {
    let header = data ? contentType : {};
    if (location) {
        header = { ...header, Location: location };
    }
    return (0, exports.statusCode)(201, data, header);
};
exports.created = created;
const noContent = (data) => (0, exports.statusCode)(204, data, data ? contentType : undefined);
exports.noContent = noContent;
const badRequest = (detail) => (0, exports.statusCode)(400, { ...badRequestProblemDetails, detail }, contentTypeProblemDetails);
exports.badRequest = badRequest;
const notFound = (detail) => (0, exports.statusCode)(404, { ...notFoundProblemDetails, detail }, contentTypeProblemDetails);
exports.notFound = notFound;
const unprocessableEntity = (detail) => (0, exports.statusCode)(422, { ...unprocessableEntityProblemDetails, detail }, contentTypeProblemDetails);
exports.unprocessableEntity = unprocessableEntity;
