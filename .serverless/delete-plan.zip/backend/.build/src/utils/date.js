"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toUnixTime = toUnixTime;
exports.fromUnixTime = fromUnixTime;
exports.fromISOToDate = fromISOToDate;
exports.formatDate = formatDate;
exports.isDate = isDate;
function toUnixTime(date) {
    return Math.floor(date.getTime() / 1000);
}
function fromUnixTime(epoch) {
    return new Date(epoch * 1000);
}
function fromISOToDate(isoDate) {
    return new Date(isoDate);
}
function formatDate(date) {
    const monthsAbbr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const day = date.getDate();
    const monthIndex = date.getMonth();
    const year = date.getFullYear();
    const formattedDate = `${day}-${monthsAbbr[monthIndex]}-${year}`;
    return formattedDate;
}
function isDate(dateToTest) {
    if (!dateToTest)
        return false;
    if (!dateToTest.trim())
        return false;
    if (!/\d+-\d+-\d+/.test(dateToTest))
        return false;
    return !isNaN(Date.parse(dateToTest));
}
