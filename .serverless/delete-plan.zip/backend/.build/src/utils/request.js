"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatBody = void 0;
const generalDateProperties = ['date', 'createdAt', 'updatedAt'];
const formatBody = (body, dateProps) => {
    const result = JSON.parse(body);
    const allDateProps = [...generalDateProperties, ...(dateProps || [])];
    for (const dateProp of allDateProps) {
        const value = result[dateProp];
        if (typeof value === 'string' || typeof value === 'number' || value instanceof Date) {
            result[dateProp] = new Date(value);
        }
    }
    return result;
};
exports.formatBody = formatBody;
