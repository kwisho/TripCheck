"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchDistanceFromGoogleMaps = fetchDistanceFromGoogleMaps;
const url_1 = require("url");
const API_KEY = process.env.GOOGLE_MAPS_API_KEY;
if (!API_KEY) {
    throw new Error('Missing GOOGLE_MAPS_API_KEY in environment variables.');
}
async function fetchDistanceFromGoogleMaps(params) {
    const { fromLocation, toLocation, departureTime, transportType } = params;
    new url_1.URLSearchParams({
        origins: fromLocation.name,
        destinations: toLocation.name,
        mode: transportType,
        departure_time: Math.floor(departureTime.getTime() / 1000).toString(),
        language: 'ja',
        key: API_KEY,
    });
    const searchParams = new url_1.URLSearchParams({
        origins: fromLocation.name,
        destinations: toLocation.name,
        mode: transportType,
        departure_time: Math.floor(departureTime.getTime() / 1000).toString(),
        language: 'ja',
        key: API_KEY,
    });
    const url = `https://maps.googleapis.com/maps/api/distancematrix/json?${searchParams.toString()}`;
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Failed to fetch from Google Maps API: ${response.statusText}`);
    }
    const data = await response.json();
    const element = data?.rows?.[0]?.elements?.[0];
    if (!element || element.status !== 'OK') {
        throw new Error(`Invalid response from Google Maps API: ${JSON.stringify(element)}`);
    }
    return {
        durationMinutes: Math.ceil(element.duration.value / 60),
        distanceMeters: element.distance.value,
        summary: `${element.duration.text} / ${element.distance.text}`,
    };
}
