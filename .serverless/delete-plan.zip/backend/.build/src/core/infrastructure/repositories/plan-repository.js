"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlanRepository = void 0;
const dummyPlans_1 = require("@fixtures/dummyPlans");
const utils_1 = require("@trip-check/utils");
const dynamo_js_1 = require("../dynamo.js");
const base_dynamodb_repository_js_1 = require("./base-dynamodb-repository.js");
class PlanRepository extends base_dynamodb_repository_js_1.BaseDynamoRepository {
    constructor(ddbDocumentClient = dynamo_js_1.ddb) {
        super(ddbDocumentClient, 'user');
    }
    mapEntity(record) {
        record.birthday = (0, utils_1.fromISOToDate)(record.birthday);
        return record;
    }
    handleModel(entity) {
        const model = entity;
        model.gsi1pk = `${entity.id}`;
        return entity;
    }
    async get(id) {
        const plan = (0, dummyPlans_1.dummyFullPlan)(id);
        console.log('get:', plan);
        return plan;
    }
    async getPagedByFilters(userId, startDate, endDate, advisability, count, nextToken) {
        console.log(userId);
        console.log(startDate);
        console.log(endDate);
        console.log(advisability);
        console.log(count);
        console.log(nextToken);
        const plans = [
            {
                id: '1',
                name: '北海道ドライブ旅行',
                startDate: new Date('2025-05-01'),
                endDate: new Date('2025-05-05'),
                description: '札幌から函館までの絶景ドライブ',
                advisability: true,
                userId: 'user123',
                imageUrl: 'https://picsum.photos/200/300',
            },
            {
                id: '2',
                name: 'ランニングマラソン',
                startDate: new Date('2024-05-02'),
                endDate: new Date('2024-05-03'),
                description: '東京で行われる市民マラソンに参加',
                advisability: false,
                userId: 'user123',
                imageUrl: 'https://picsum.photos/200/300',
            },
        ];
        return {
            items: plans,
        };
    }
}
exports.PlanRepository = PlanRepository;
