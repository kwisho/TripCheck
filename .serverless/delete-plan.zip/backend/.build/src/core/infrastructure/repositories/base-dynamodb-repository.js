"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ItemNotFoundError = exports.BaseDynamoRepository = void 0;
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const crypto_1 = require("crypto");
const dynamoDbWriteBatchSize = 25;
const dynamoDbGetBatchSize = 100;
const tableName = process.env.TABLE_NAME;
class BaseDynamoRepository {
    ddb;
    constructor(ddb, pk) {
        this.ddb = ddb;
        this.pk = pk;
    }
    pk;
    async get(id) {
        const getCommand = new lib_dynamodb_1.GetCommand(this.getKeyModel(id));
        const result = await this.ddb.send(getCommand);
        if (result.Item) {
            return this.handleEntity(result.Item);
        }
        return undefined;
    }
    async getAll() {
        const result = [];
        await this.getAllPages(result);
        return result;
    }
    async getAllPages(list, nextToken = undefined) {
        const exclusiveStartKey = this.getExclusiveStartKey(nextToken);
        const queryCommand = new lib_dynamodb_1.QueryCommand({
            TableName: tableName,
            ExclusiveStartKey: exclusiveStartKey,
            KeyConditionExpression: 'pk = :pk',
            ExpressionAttributeValues: {
                ':pk': this.pk,
            },
        });
        const result = await this.ddb.send(queryCommand);
        nextToken = this.getNextToken(result.LastEvaluatedKey);
        list.push(...result.Items);
        if (nextToken) {
            await this.getAllPages(list, nextToken);
        }
    }
    async getPaged(count, nextToken) {
        const limit = count ? count : 10;
        const exclusiveStartKey = this.getExclusiveStartKey(nextToken);
        const queryCommand = new lib_dynamodb_1.QueryCommand({
            TableName: tableName,
            ExclusiveStartKey: exclusiveStartKey,
            Limit: limit,
            KeyConditionExpression: 'pk = :pk',
            ExpressionAttributeValues: {
                ':pk': this.pk,
            },
        });
        const result = await this.ddb.send(queryCommand);
        if (!result.Items) {
            return {
                items: [],
            };
        }
        const items = result.Items.map((item) => this.handleEntity(item));
        count = result.Count;
        nextToken = this.getNextToken(result.LastEvaluatedKey);
        return {
            items,
            count,
            nextToken,
        };
    }
    async create(entity, id = undefined) {
        const dynamoModel = entity;
        dynamoModel.pk = this.pk;
        dynamoModel.id = id ? id : this.generateId();
        const model = this.handleModel(dynamoModel);
        const putCommand = new lib_dynamodb_1.PutCommand({
            TableName: tableName,
            Item: model,
        });
        await this.ddb.send(putCommand);
        return this.handleEntity(entity);
    }
    async update(id, entity, updateModel) {
        const currentItem = await this.get(id);
        if (!currentItem) {
            throw new ItemNotFoundError(`Item with id ${id} not found`);
        }
        const model = this.handleModel(entity);
        if (!updateModel) {
            updateModel = this.getUpdateModel(model);
        }
        const keyModel = this.getKeyModel(id);
        const updateCommand = new lib_dynamodb_1.UpdateCommand({
            ...keyModel,
            ...updateModel,
        });
        await this.ddb.send(updateCommand);
        return this.handleEntity(entity);
    }
    async batchGet(sks) {
        const batches = [];
        for (let i = 0; i < sks.length; i += dynamoDbGetBatchSize) {
            batches.push(sks.slice(i, i + dynamoDbGetBatchSize));
        }
        if (batches.length === 0)
            return Promise.resolve([]);
        const batchPromises = [];
        for (const batch of batches) {
            const batchGetInput = {
                RequestItems: {
                    [tableName]: {
                        Keys: batch.map((sk) => ({
                            pk: this.pk,
                            sk: sk,
                        })),
                    },
                },
            };
            const batchGetCommand = new lib_dynamodb_1.BatchGetCommand(batchGetInput);
            batchPromises.push(this.ddb.send(batchGetCommand));
        }
        const batchResults = (await Promise.all(batchPromises));
        const hasError = !batchResults.every((result) => result.$metadata.httpStatusCode === 200);
        if (hasError) {
            throw new Error('Error on batch get operation on base repository.');
        }
        const result = [];
        for (const getBatchResult of batchResults) {
            getBatchResult.Responses?.[tableName]?.forEach((item) => {
                result.push(this.mapEntity(item));
            });
        }
        return result;
    }
    async batchWrite(items) {
        const batches = [];
        for (let i = 0; i < items.length; i += dynamoDbWriteBatchSize) {
            batches.push(items.slice(i, i + dynamoDbWriteBatchSize));
        }
        if (batches.length === 0)
            return Promise.resolve(0);
        const batchPromises = [];
        for (const batch of batches) {
            const commandInput = {
                RequestItems: {
                    [tableName]: batch.map((item) => ({
                        PutRequest: {
                            Item: item,
                        },
                    })),
                },
            };
            const batchWriteCommand = new lib_dynamodb_1.BatchWriteCommand(commandInput);
            batchPromises.push(this.ddb.send(batchWriteCommand));
        }
        const results = (await Promise.all(batchPromises));
        const hasError = !results.every((result) => result.$metadata.httpStatusCode === 200);
        if (hasError) {
            throw new Error('Error on batch write operation on base repository.');
        }
        return items.length;
    }
    async batchDelete(sks) {
        const batches = [];
        for (let i = 0; i < sks.length; i += dynamoDbWriteBatchSize)
            batches.push(sks.slice(i, i + dynamoDbWriteBatchSize));
        if (batches.length === 0)
            return Promise.resolve(0);
        const batchPromises = [];
        for (const batch of batches) {
            const commandInput = {
                RequestItems: {
                    [tableName]: batch.map((sk) => ({
                        DeleteRequest: {
                            Key: {
                                pk: this.pk,
                                sk: sk,
                            },
                        },
                    })),
                },
            };
            const batchWriteCommand = new lib_dynamodb_1.BatchWriteCommand(commandInput);
            batchPromises.push(this.ddb.send(batchWriteCommand));
        }
        const results = (await Promise.all(batchPromises));
        console.log(`result ${JSON.stringify(results)}`);
        const hasError = !results.every((result) => result.$metadata.httpStatusCode === 200);
        if (hasError) {
            throw new Error('Error on batch write operation on base repository.');
        }
        return sks.length;
    }
    async delete(id) {
        const deleteCommand = new lib_dynamodb_1.DeleteCommand(this.getKeyModel(id));
        const result = await this.ddb.send(deleteCommand);
        console.log(`delete dynamo: ${JSON.stringify(result, null, 2)}`);
        return result.$metadata.httpStatusCode === 200;
    }
    async getByGSI(index, gsipk, gsisk, count, nextToken) {
        const exclusiveStartKey = this.getExclusiveStartKey(nextToken);
        let keyConditionExpression = `gsi${index}pk = :gsipk`;
        const expressionAttributeValues = { ':gsipk': gsipk };
        if (gsisk) {
            keyConditionExpression += ` AND gsi${index}sk = :gsisk`;
            expressionAttributeValues[':gsisk'] = gsisk;
        }
        const queryParam = {
            TableName: tableName,
            IndexName: `GSI${index}`,
            KeyConditionExpression: keyConditionExpression,
            ExpressionAttributeValues: expressionAttributeValues,
        };
        if (count) {
            queryParam.Limit = count;
            queryParam.ExclusiveStartKey = exclusiveStartKey;
        }
        const queryCommand = new lib_dynamodb_1.QueryCommand(queryParam);
        const result = await this.ddb.send(queryCommand);
        nextToken = this.getNextToken(result.LastEvaluatedKey);
        return {
            items: (result.Items ?? []).map((x) => this.handleEntity(x)),
            count: result.Count,
            nextToken: nextToken,
        };
    }
    getExclusiveStartKey(nextToken) {
        if (!nextToken)
            return undefined;
        const nextTokenJson = Buffer.from(nextToken, 'base64').toString('ascii');
        const exclusiveStartKey = JSON.parse(nextTokenJson);
        return exclusiveStartKey;
    }
    getNextToken(lastEvaluatedKey) {
        if (!lastEvaluatedKey)
            return undefined;
        const json = JSON.stringify(lastEvaluatedKey);
        return Buffer.from(json, 'ascii').toString('base64');
    }
    getUpdateModel(entity) {
        const updateExpression = [];
        const expressionAttributeNames = {};
        const expressionAttributeValues = {};
        for (const [key, value] of Object.entries(entity)) {
            if (key === 'pk' || key === 'id' || key === 'id')
                continue;
            updateExpression.push(`#${key} = :${key}`);
            expressionAttributeNames[`#${key}`] = `${key}`;
            expressionAttributeValues[`:${key}`] = value ?? null;
        }
        return {
            UpdateExpression: `SET ${updateExpression.join(',')}`,
            ExpressionAttributeNames: expressionAttributeNames,
            ExpressionAttributeValues: expressionAttributeValues,
        };
    }
    mapEntity(record) {
        return record;
    }
    handleModel(entity) {
        return entity;
    }
    handleEntity(record) {
        const model = record;
        const { pk, gsi1pk, gsi1sk, gsi2pk, gsi2sk, ...rest } = model;
        return this.mapEntity(rest);
    }
    generateId() {
        return (0, crypto_1.randomUUID)();
    }
    getKeyModel(id) {
        return {
            TableName: tableName,
            Key: {
                pk: this.pk,
                id: id,
            },
        };
    }
}
exports.BaseDynamoRepository = BaseDynamoRepository;
class ItemNotFoundError extends Error {
}
exports.ItemNotFoundError = ItemNotFoundError;
