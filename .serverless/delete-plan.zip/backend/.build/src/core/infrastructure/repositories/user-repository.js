"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserRepository = void 0;
const dynamo_js_1 = require("../dynamo.js");
const base_dynamodb_repository_js_1 = require("./base-dynamodb-repository.js");
const utils_1 = require("@trip-check/utils");
class UserRepository extends base_dynamodb_repository_js_1.BaseDynamoRepository {
    constructor(ddbDocumentClient = dynamo_js_1.ddb) {
        super(ddbDocumentClient, 'user');
    }
    mapEntity(record) {
        record.birthday = (0, utils_1.fromISOToDate)(record.birthday);
        return record;
    }
    handleModel(entity) {
        const model = entity;
        model.gsi1pk = `${entity.id}`;
        return entity;
    }
}
exports.UserRepository = UserRepository;
