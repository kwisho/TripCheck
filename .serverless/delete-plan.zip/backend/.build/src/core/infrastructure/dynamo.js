"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ddb = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const { AWS_REGION } = process.env;
exports.ddb = lib_dynamodb_1.DynamoDBDocumentClient.from(new client_dynamodb_1.DynamoDBClient({
    apiVersion: '2012-08-10',
    region: AWS_REGION,
}));
