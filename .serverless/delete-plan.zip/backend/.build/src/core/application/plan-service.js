"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlanService = void 0;
const types_1 = require("@trip-check/types");
const plan_repository_js_1 = require("../infrastructure/repositories/plan-repository.js");
class PlanService {
    planRepository;
    constructor(planRepository = new plan_repository_js_1.PlanRepository()) {
        this.planRepository = planRepository;
    }
    async get(id) {
        console.log('PlanService.get called with id');
        const model = await this.planRepository.get(id);
        if (!model) {
            return {
                errors: [`There is not a plan for the id '${id}'.`],
            };
        }
        return { model };
    }
    async create(input) {
        const validation = types_1.PlanValidator.validate(input);
        if (validation.error) {
            const errors = validation.error.details.map((x) => x.message);
            return { errors };
        }
        const model = await this.planRepository.create(input);
        return { model };
    }
    async update(id, input) {
        const validation = types_1.PlanValidator.validate(input);
        if (validation.error) {
            const errors = validation.error.details.map((x) => x.message);
            return { errors };
        }
        const model = await this.planRepository.update(id, input);
        return { model };
    }
    async delete(id) {
        const result = await this.planRepository.delete(id);
        return { model: result };
    }
    async getPaged(userId, startDate, endDate, advisability, count, nextToken) {
        console.log(`Starting checking Plans`);
        console.log(userId);
        console.log(startDate);
        console.log(endDate);
        console.log(advisability);
        console.log(count);
        console.log(nextToken);
        const plans = [
            {
                id: '1',
                name: '北海道ドライブ旅行',
                startDate: new Date('2025-05-01'),
                endDate: new Date('2025-05-05'),
                description: '札幌から函館までの絶景ドライブ',
                userId: 'user123',
                advisability: true,
                imageUrl: 'https://picsum.photos/200/300',
            },
            {
                id: '2',
                name: 'ランニングマラソン',
                startDate: new Date('2024-05-02'),
                endDate: new Date('2024-05-03'),
                description: '東京で行われる市民マラソンに参加',
                userId: 'user123',
                advisability: false,
                imageUrl: 'https://picsum.photos/200/300',
            },
            {
                id: '3',
                name: '富士山ハイキング',
                startDate: new Date('2024-04-10'),
                endDate: new Date('2024-04-11'),
                description: '富士山周辺をゆったりハイキング',
                userId: 'user123',
                advisability: true,
                imageUrl: 'https://picsum.photos/200/300',
            },
        ];
        return {
            model: {
                items: plans,
                count: plans.length,
                nextToken: undefined,
            },
        };
    }
}
exports.PlanService = PlanService;
