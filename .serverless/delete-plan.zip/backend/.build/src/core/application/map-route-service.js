"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MapRouteService = void 0;
const google_maps_api_1 = require("../infrastructure/external/google-maps-api");
class MapRouteService {
    async calculateRoute(command) {
        try {
            const result = await (0, google_maps_api_1.fetchDistanceFromGoogleMaps)({
                fromLocation: command.fromLocation,
                toLocation: command.toLocation,
                transportType: command.transportType,
                departureTime: command.departureTime,
            });
            return { model: result };
        }
        catch (e) {
            console.error(e);
            return {
                errors: ['経路取得に失敗しました'],
            };
        }
    }
}
exports.MapRouteService = MapRouteService;
