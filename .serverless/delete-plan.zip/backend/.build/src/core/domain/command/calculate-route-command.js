"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CalculateRouteCommand = void 0;
class CalculateRouteCommand {
    fromLocation;
    toLocation;
    transportType;
    departureTime;
    constructor(fromLocation, toLocation, transportType, departureTime) {
        this.fromLocation = fromLocation;
        this.toLocation = toLocation;
        this.transportType = transportType;
        this.departureTime = departureTime;
    }
}
exports.CalculateRouteCommand = CalculateRouteCommand;
